package com.example.mukul.kabil;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {



    TextToSpeech T1;
    TextView tv;
    TextView dis;
    final int SPEECH_RECOGNITION_CODE=1;
    int fact=-100;
    GestureDetector m;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CustomGestureDetector customGestureDetector =new CustomGestureDetector();
        m=new GestureDetector(this,customGestureDetector);

         fact=-100;

        Dexter.withActivity(MainActivity.this).withPermission(Manifest.permission.CALL_PHONE).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse response) {

            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse response) {

            }

            @Override
            public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {

            }
        }).check();










        dis= (TextView) findViewById(R.id.display);
        T1=new TextToSpeech(this,this);
        tv= (TextView) findViewById(R.id.TV);

        shuru();

    }



    public void shuru()
    {
        fact=0;
        Thread t=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                    T1.speak(dis.getText().toString(),TextToSpeech.QUEUE_FLUSH,null);
                    fact=0;
                    in();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t.start();


    }



    public void in()
    {
        fact=0;
        Thread t=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                    startSpeechToText();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t.start();



    }



    private void startSpeechToText() {
        fact=0;
        Intent intent= new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        //intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"speak something......");


        try {
            startActivityForResult(intent, SPEECH_RECOGNITION_CODE);
        }

        catch (ActivityNotFoundException e)
        {
            Toast.makeText(this,"sorrty ! speech recogination is not supported in this ",Toast.LENGTH_SHORT).show();
        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        fact=0;
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode)
        {
            case SPEECH_RECOGNITION_CODE: {
                if(resultCode==RESULT_OK && null!=data)
                {
                    ArrayList<String> result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String text =result.get(0);

                    text.replace(" ","");

                    if(text.contains("9") || text.contains("8") || text.contains("7") || text.contains("6") || text.contains("5"))
                    {


                        tv.setText(text);

                        Intent i = new Intent(Intent.ACTION_CALL);
                        i.setData(Uri.parse("tel:" + text));
                        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }

                        startActivity(i);


                    }

                    else {
                        if (text.contains("call")) {
                            dis.setText("PLEASE ENTER A NUMBER AFTER BEEP");
                            T1.speak(dis.getText().toString(),TextToSpeech.QUEUE_FLUSH,null);

                            call();
                        }

                        else
                        {
                            dis.setText("PLEASE REQUEST AGAIN");
                        }

                    }



                }
                break;
            }

        }

    }







    public void call()
    {
        fact=0;

        Thread t=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                    startSpeechToText();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t.start();




    }

    public boolean onTouchEvent(MotionEvent event) {
        m.onTouchEvent(event);
        return super.onTouchEvent(event);
    }






    class CustomGestureDetector extends GestureDetector.SimpleOnGestureListener{

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

            if(e2.getX() > e1.getX())
            {
                fact=0;
                Intent I=new Intent(MainActivity.this,MainActivity.class);
                startActivity(I);
                finish();

            }



            return super.onFling(e1, e2, velocityX, velocityY);
        }
    }












    @Override
    public void onInit(int status) {

    }

}
